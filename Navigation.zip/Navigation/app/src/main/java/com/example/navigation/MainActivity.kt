package com.example.navigation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.navigation.ui.theme.NavigationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        installSplashScreen()
        setContent {
            NavigationTheme {
                val navController = rememberNavController()

                NavHost(navController = navController,
                    startDestination = Destinations.HOME.name
                ) {
                    composable(
                        route = Destinations.HOME.name
                    ){
                        HomeScreen(
                            navigateToSearchScreen = {
                                navController.navigate(Destinations.SEARCH.name)
                            }
                        )
                    }

                    composable(
                        route = Destinations.SEARCH.name
                    ){
                        SearchScreen(
                            navigateToProfileScreenWithoutArgument = {
                                navController.navigate(Destinations.PROFILE.name)
                            },
                            navigateToProfileScreenWithArgument = {
                                navController.navigate("${Destinations.PROFILE.name}/$it")
                            }
                        )
                    }

                    composable(
                        route = "${Destinations.PROFILE.name}/{playerName}",
                        arguments = listOf(
                            navArgument("playerName"){
                            type = NavType.StringType
                            defaultValue = "EMPTY"
                        },

//                            navArgument("jerseyNum"){
//                                type = NavType.IntType
//                                defaultValue = "69"
//                            }
                        ),

                    ){
                        ProfileScreen(
                            name = it.arguments?.getString("playerName") ?: ""
                        )
                    }
                }
            }
        }
    }
}


enum class Destinations{
    HOME,
    SEARCH,
    PROFILE
}