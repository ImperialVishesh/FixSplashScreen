package com.example.navigation

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.navigation.ui.theme.NavigationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        installSplashScreen()
        setContent {
            NavigationTheme {
                val navController = rememberNavController()

                NavHost(navController = navController,
                    startDestination = Destinations.HOME.name
                ) {
                    composable(
                        route = Destinations.HOME.name
                    ){
                        HomeScreen(
                            navigateToSearchScreen = {
                                navController.navigate(Destinations.SEARCH.name)
                            }
                        )
                    }

                    composable(
                        route = Destinations.SEARCH.name
                    ){
                        SearchScreen(
                            navigateToProfileScreen = {
                                navController.navigate(Destinations.PROFILE.name)
                            }
                        )
                    }

                    composable(
                        route = Destinations.PROFILE.name
                    ){
                        ProfileScreen()
                    }
                }
            }
        }
    }
}


enum class Destinations{
    HOME,
    SEARCH,
    PROFILE
}