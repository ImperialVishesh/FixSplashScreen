package com.example.navigation

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SearchScreen(modifier: Modifier = Modifier,
                 navigateToProfileScreenWithoutArgument: () -> Unit,
                 navigateToProfileScreenWithArgument: (String) -> Unit,
                 listOfPlayer: List<String> = listOf("Kohli", "Rohit", "Bumrah", "Dhoni")
){
    Column(modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LazyColumn {
            items(listOfPlayer){playername->
                Text(text = playername, modifier = Modifier
                    .padding(8.dp)
                    .clickable {
                        navigateToProfileScreenWithArgument(playername)
                    })
            }
        }
        Button(onClick = navigateToProfileScreenWithoutArgument) {
            Text(text = "Welcome to SearchScreen")
        }

    }
}